package dev.mobile.tp3person

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import dev.mobile.tp3person.ui.DetailScreen
import dev.mobile.tp3person.ui.theme.Tp3PersonTheme

class DetailActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PERSON = "PERSON_DATA"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val person = intent.getParcelableExtra(EXTRA_PERSON, Person::class.java)

        enableEdgeToEdge()
        setContent {
            Tp3PersonTheme {
                DetailScreen(
                    personToEdit = person,
                    onSave = { person ->
                        val resultIntent = Intent().putExtra(EXTRA_PERSON, person)
                        setResult(RESULT_OK, resultIntent)
                        finish()
                    },
                    onCancel = { finish() }
                )
            }
        }
    }
}


