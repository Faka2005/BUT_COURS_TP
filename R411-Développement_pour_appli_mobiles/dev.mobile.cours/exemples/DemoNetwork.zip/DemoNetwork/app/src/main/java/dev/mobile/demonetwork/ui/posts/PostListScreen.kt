package dev.mobile.demonetwork.ui.posts

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mobile.demonetwork.data.data.model.Post

@Composable
fun PostListScreen(state: PostUiState) {

    Scaffold(
        topBar = { Text("Demo Network", modifier = Modifier.padding(16.dp)) }
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)) {
            when (state) {
                is PostUiState.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                is PostUiState.Error -> Text(
                    "Erreur: ${state.message}",
                    Modifier.align(Alignment.Center)
                )

                is PostUiState.Success -> {
                    PostItems(state.posts)
                }
            }
        }
    }
}

@Composable
fun PostItems(posts: List<Post>) {
    LazyColumn {
        items(posts) { post ->
            PostItem(post)
        }
    }
}

@Composable
fun PostItem(post: Post) {
    Card(modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = post.title, style = MaterialTheme.typography.titleMedium)
            Text(text = post.body, style = MaterialTheme.typography.bodySmall)
        }
    }
}