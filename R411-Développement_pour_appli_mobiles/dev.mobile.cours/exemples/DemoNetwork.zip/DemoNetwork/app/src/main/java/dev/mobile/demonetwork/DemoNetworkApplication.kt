package dev.mobile.demonetwork

import android.app.Application
import dev.mobile.demonetwork.data.remote.PostRemoteDataSource
import dev.mobile.demonetwork.data.repository.PostRepository
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

class DemoNetworkApplication : Application(){
    val httpClient by lazy { HttpClient(Android) {
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                coerceInputValues = true
            })
        }
    }
}

    val repository by lazy {
        PostRepository(PostRemoteDataSource(httpClient))
    }
}