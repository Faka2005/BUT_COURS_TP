package dev.mobile.tp2temperatureconverter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import dev.mobile.tp2temperatureconverter.util.TemperatureCalculator
import dev.mobile.tp2temperatureconverter.ui.theme.Tp2TemperatureConverterTheme

@Composable
fun TemperatureConverterScreen(modifier: Modifier = Modifier) {
    var celsiusValue = 0f

    val fahrenheitValue = 0f

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text(text = "Convertisseur de Température", style = MaterialTheme.typography.headlineMedium)

        Column {
            Text(text = "Celsius : ${celsiusValue.toInt()}°C")
            OutlinedTextField(
                value = celsiusValue.toInt().toString(),
                onValueChange = {},
                label = { Text("Valeur Celsius") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        HorizontalDivider()

        Slider(
            value = celsiusValue,
            onValueChange = { celsiusValue = it },
            valueRange = -100f..100f
        )

        HorizontalDivider()

        Column {
            Text(text = "Fahrenheit : ${fahrenheitValue.toInt()}°F")
            OutlinedTextField(
                value = fahrenheitValue.toInt().toString(),
                onValueChange = { },
                label = { Text("Valeur Fahrenheit") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Tp2TemperatureConverterTheme {
        TemperatureConverterScreen()
    }
}
