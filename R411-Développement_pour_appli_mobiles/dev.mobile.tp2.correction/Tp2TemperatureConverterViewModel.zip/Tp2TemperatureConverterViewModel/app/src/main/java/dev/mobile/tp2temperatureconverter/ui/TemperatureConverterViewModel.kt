package dev.mobile.tp2temperatureconverter.ui

import androidx.compose.runtime.State
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import dev.mobile.tp2temperatureconverter.TemperatureCalculator

class TemperatureConverterViewModel : ViewModel() {

    private val _celsius : MutableState<Float> = mutableStateOf<Float>(0f)
    val celsius : State<Float>
        get() = _celsius

    fun updateCelsius(newValue : Float) {
        _celsius.value = newValue
    }

    fun updateFahrenheit(newValue : Float) {
        _celsius.value = TemperatureCalculator.fahrenheitToCelsius(newValue)
    }

}