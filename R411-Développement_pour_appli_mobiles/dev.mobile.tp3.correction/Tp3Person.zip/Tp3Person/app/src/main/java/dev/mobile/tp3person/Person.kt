package dev.mobile.tp3person

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Locale

@Parcelize
data class Person(
    val firstName: String,
    val lastName: String,
    val phone: String,
    val id: String = java.util.UUID.randomUUID().toString()
) : Parcelable{

    fun toUpercase(): Person {
        return this.copy(lastName = lastName.uppercase(Locale.getDefault()))
    }

}

object PersonData {
    val allPersons: List<Person> = listOf(
        Person("Thiago","Blanc","04-62-88-92-08"),
        Person("Yann","Carpentier","02-16-13-95-42"),
        Person("Anaïs","Dupuis","05-57-81-92-34"),
        Person("Lou","Carpentier","04-96-54-85-94"),
        Person("Eline","Rolland","03-64-89-57-06"),
        Person("Logan","Lefebvre","03-01-45-86-76"),
        Person("Antonin","Lefevre","01-42-57-29-13"),
        Person("Charline","Le Gall","01-70-17-41-46"),
        Person("Maya","Morin","01-69-84-25-63"),
        Person("Mélody","Clement","04-46-51-68-16"),
        Person("Léonard","Morin","03-43-45-66-58"),
        Person("Ezio","Lopez","04-58-26-04-91"),
        Person("Soan","Philippe","04-01-27-38-99"),
        Person("Anatole","Moulin","05-63-28-29-00"),
        Person("Noam","Rey","01-86-28-61-35"),
        Person("Louisa","Bertrand","04-13-73-48-91"),
        Person("Margaux","Joly","02-09-40-11-76"),
        Person("Romain","Adam","04-07-91-91-51"),
        Person("Timeo","Blanchard","04-32-96-16-42"),
        Person("Léane","Renard","01-94-53-51-62"),
        Person("Nolhan","Barbier","04-61-10-52-66"),
        Person("Lina","Dubois","03-08-39-65-61"),
        Person("Johan","Marchand","04-57-55-42-94"),
        Person("Elise","Henry","02-04-91-35-10"),
        Person("Joshua","Morel","02-08-24-18-20"),
        Person("Emma","Marchand","02-04-04-94-24"),
        Person("Thiago","Renaud","05-33-08-63-04"),
        Person("Elio","Garnier","05-03-54-08-62"),
        Person("Gabin","Deschamps","04-55-03-58-64"),
        Person("Lou","Michel","05-27-16-17-09"),
        Person("Mathilde","Dumas","04-69-31-28-48"),
        Person("Laurine","Leroux","01-49-16-48-57"),
        Person("Maëline","Riviere","03-95-65-27-06"),
        Person("Thiago","Roux","04-39-21-41-98"),
        Person("Ewen","Arnaud","05-03-32-39-40"),
        Person("Léon","Colin","02-97-43-17-76"),
        Person("Nathan","Nicolas","03-42-97-88-22"),
        Person("Maëly","Roux","04-54-12-00-42"),
        Person("Candice","Fleury","03-47-13-28-14"),
        Person("Eléonore","Schmitt","04-52-29-07-64"),
        Person("Bérénice","Colin","04-60-11-46-79"),
        Person("Maëlyne","Thomas","05-54-76-87-58"),
        Person("Elouan","Moulin","04-97-52-17-60"),
        Person("Cléa","Petit","02-86-57-97-78"),
        Person("Héloïse","Charles","02-84-99-49-76"),
        Person("Mathieu","Blanc","05-69-61-10-79"),
        Person("Matéo","Hubert","01-35-02-14-83"),
        Person("Hélèna","Bourgeois","04-83-13-94-55"),
        Person("Tom","Leroy","05-63-89-91-88"),
        Person("Alizee","Martinez","01-31-59-61-16")
    )
}