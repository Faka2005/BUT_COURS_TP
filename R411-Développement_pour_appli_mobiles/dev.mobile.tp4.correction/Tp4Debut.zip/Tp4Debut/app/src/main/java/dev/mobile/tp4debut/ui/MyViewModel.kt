package dev.mobile.tp4debut.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import dev.mobile.tp4debut.data.Todo
import dev.mobile.tp4debut.data.MyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import dev.mobile.tp4debut.MyApplication
import dev.mobile.tp4debut.data.Resource

sealed interface ScreenState {
    object Idle : ScreenState
    object Loading : ScreenState
    data class SuccessPost(val thePost: Todo) : ScreenState
    data class SuccessText(val theText: String) : ScreenState
    data class SuccessImage(val theUrl: String) : ScreenState
    data class Error(val message: String) : ScreenState
}

class MyViewModel(private val repository: MyRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<ScreenState>(ScreenState.Idle)
    val uiState = _uiState.asStateFlow()


    fun fetchGet() {
        viewModelScope.launch {
            _uiState.value = ScreenState.Loading
            when (val result = repository.get()) {
                is Resource.Success -> _uiState.value = ScreenState.SuccessText(result.data)
                is Resource.Error -> _uiState.value =
                    ScreenState.Error(result.exception.message ?: "Erreur")
            }
        }
    }

    fun fetchPost() {
        viewModelScope.launch {
            _uiState.value = ScreenState.Loading
            when (val result = repository.post()) {
                is Resource.Success -> _uiState.value = ScreenState.SuccessText(result.data)
                is Resource.Error -> _uiState.value =
                    ScreenState.Error(result.exception.message ?: "Erreur")
            }
        }
    }

    fun fetchImage() {
        viewModelScope.launch {
            _uiState.value = ScreenState.Loading
            _uiState.value =  when (val result = repository.image()) {
                is Resource.Success -> ScreenState.SuccessImage(result.data)
                is Resource.Error ->
                    ScreenState.Error(result.exception.message ?: "Erreur")
            }
        }
    }

    fun fetchJson(id: Int) {
        viewModelScope.launch {
            _uiState.value = ScreenState.Loading
            when (val result = repository.json(id)) {
                is Resource.Success -> _uiState.value = ScreenState.SuccessPost(result.data)
                is Resource.Error -> _uiState.value =
                    ScreenState.Error(result.exception.message ?: "Erreur")
            }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = (this[APPLICATION_KEY] as MyApplication)
                MyViewModel(repository = app.repository)
            }
        }
    }
}