package dev.mobile.demonetwork

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import dev.mobile.demonetwork.data.remote.PostRemoteDataSource
import dev.mobile.demonetwork.data.repository.PostRepository
import dev.mobile.demonetwork.ui.posts.PostListScreen
import dev.mobile.demonetwork.ui.posts.PostViewModel
import dev.mobile.demonetwork.ui.theme.DemoNetworkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        setContent {
            val viewModel: PostViewModel = viewModel(
                factory = PostViewModel.Factory
            )
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            PostListScreen(state)
        }
    }
}
