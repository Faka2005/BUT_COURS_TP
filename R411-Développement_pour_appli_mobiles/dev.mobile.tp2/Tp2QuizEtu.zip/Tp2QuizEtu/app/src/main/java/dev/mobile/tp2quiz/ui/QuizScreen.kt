package dev.mobile.tp2quiz.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import dev.mobile.tp2quiz.data.NO_OF_QUESTIONS

@Composable
fun QuizScreen() {

    // À CHANGER
    // définition du State via le ViewModel
    val uiState = QuizUiState()

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (uiState.isGameOver) {
            // FIN
            Text("Fin du quiz  !", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Score final : ${uiState.score} / $NO_OF_QUESTIONS",
                style = MaterialTheme.typography.headlineSmall
            )
            Button(onClick = {/* TODO */}) {
                Text("Recommencer")
            }
        } else {
            Text("Score: ${uiState.score}", style = MaterialTheme.typography.headlineSmall)
            Text("Question ${uiState.questionNumber} / $NO_OF_QUESTIONS")

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = uiState.question,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(32.dp))

            Box(
                modifier = Modifier.height(60.dp),
                contentAlignment = Alignment.Center
            ) {
                if (uiState.resultMessage.isNotEmpty()) {
                    Text(text = uiState.resultMessage)
                }
            }

            if (!uiState.isAnswered) {
                Row {
                    Button(onClick = {/* TODO */}) { Text("VRAI") }
                    Spacer(modifier = Modifier.width(16.dp))
                    Button(onClick = {/* TODO */}) { Text("FAUX") }
                }
            } else {
                Button(onClick = {/* TODO */}) {
                    Text("Suivant")
                }
            }
        }
    }
}