package dev.mobile.draftlist.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import dev.mobile.draftlist.data.Person
import java.time.LocalDate
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import dev.mobile.draftlist.data.PersonData


@Composable
fun PersonScreen(/*viewModel: PersonViewModel = viewModel()*/) {
    val people =  rememberSaveable { PersonData.allPersons.toMutableStateList() } //viewModel.people

    // À NE PAS FAIRE
    //val people = remember { PersonData.allPersons.toMutableList() }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        Button(onClick = {
            // Exemple d'ajout au clic
            //viewModel.addPerson(Person("Nouvel", "Arrivant", LocalDate.now()))
            people.add(Person("Nouvel", "Arrivant", LocalDate.now()))
        }) {
            Text("Ajouter une personne")
        }
        PersonList(people)

    }
}

@Composable
fun PersonList(persons : List<Person>) {
    val state = rememberLazyListState()

    println("${state.firstVisibleItemIndex} ${state.firstVisibleItemScrollOffset}")
    LazyColumn(
        state = state,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(start = 24.dp,end=24.dp).fillMaxSize()
    ) {
        items(persons) { person ->
            PersonItem(person)
        }
    }
}

@Composable
fun PersonItem(person: Person) {
    Text("${person.firstName} ${person.lastName}",
        style = MaterialTheme.typography.headlineMedium)
}