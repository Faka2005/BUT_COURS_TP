package dev.mobile.tp4debut.data

import io.ktor.client.HttpClient
import io.ktor.client.request.forms.submitForm
import io.ktor.client.request.get
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.parameters

class MyRepository (private val client: HttpClient) {

    suspend fun get(): Resource<String> {
        return Resource.Success("À modifier")
    }

    suspend fun post(): Resource<String> {
        // try/catch
        return Resource.Success("À modifier")
    }

    suspend fun getImage(): Resource<String> {
        return Resource.Success("url de l'image")
    }

    suspend fun getJson(id: Int): Resource<Todo> {
        return  Resource.Error(Exception("TODO()"))

    }

}