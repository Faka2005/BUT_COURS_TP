package dev.mobile.tp4debut.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import dev.mobile.tp4debut.data.Todo
import dev.mobile.tp4debut.data.MyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import dev.mobile.tp4debut.MyApplication
import dev.mobile.tp4debut.data.Resource

sealed interface ScreenState {
    object Idle : ScreenState
    object Loading : ScreenState
    data class SuccessTodo(val theTodo: Todo) : ScreenState
    data class SuccessText(val theText: String) : ScreenState
    data class SuccessImage(val theUrl: String) : ScreenState
    data class Error(val message: String) : ScreenState
}

class MyViewModel(private val repository: MyRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<ScreenState>(ScreenState.Idle)
    val uiState = _uiState.asStateFlow()


    fun fetchGet() {
        _uiState.value = ScreenState.SuccessText("fetchGet")
    }

    fun fetchPost() {
        _uiState.value = ScreenState.SuccessText("fetchPost")
    }



    fun fetchImage() {
        _uiState.value = ScreenState.SuccessText("fetchImage")
    }



    fun fetchJson(id: Int) {
        _uiState.value = ScreenState.SuccessText("fetchJson")
    }



    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = (this[APPLICATION_KEY] as MyApplication)
                MyViewModel(repository = app.repository)
            }
        }
    }
}