package dev.mobile.tp2quiz.ui

import androidx.lifecycle.ViewModel
import dev.mobile.tp2quiz.data.NO_OF_QUESTIONS
import dev.mobile.tp2quiz.data.Question
import dev.mobile.tp2quiz.data.QuizData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class QuizViewModel : ViewModel() {


    // Questions pour ce Quiz
    private lateinit var questions: List<Question>
    private var index = 0

    // À compléter par des variables de type State ou StateFlow

    init {
        resetQuiz()
    }

    fun resetQuiz() {
        // Mélanger et piocher NO_OF_QUESTIONS questions

        // Mettre à jour l'état avec la première question
    }

    fun checkAnswer(userAnswer: Boolean) {
        // Bonne réponse ?
        val isCorrect = true

        // Mettre à jour l'état.
        // Utilisation de update si MutableStateFlow
        // et copy de data class
    }

    fun nextQuestion() {
        // Encore des questions
        if (index < NO_OF_QUESTIONS - 1) {
            //
        } else {
            // ou FIN

        }
    }
}