package dev.mobile.demonetwork.data.remote

import dev.mobile.demonetwork.data.data.model.Post
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get

class PostRemoteDataSource(private val client: HttpClient) {

    suspend fun fetchPosts(): List<Post> {
        val response =  client.get("https://jsonplaceholder.typicode.com/posts")
        return response.body<List<Post>>()
    }

}