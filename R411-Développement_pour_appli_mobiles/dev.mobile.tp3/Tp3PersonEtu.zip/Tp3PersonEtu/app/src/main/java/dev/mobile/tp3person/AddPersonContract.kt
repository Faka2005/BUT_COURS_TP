package dev.mobile.tp3person

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContract
import dev.mobile.tp3person.DetailActivity.Companion.EXTRA_PERSON


class AddPersonContract :  ActivityResultContract<Void?, Person?>(){
    override fun createIntent(
        context: Context,
        input: Void?
    ): Intent {
        return Intent(context, DetailActivity::class.java)
    }

    override fun parseResult(
        resultCode: Int,
        intent: Intent?
    ): Person? {
        var res : Person? = null
        if (resultCode == Activity.RESULT_OK)
            res = intent?.getParcelableExtra(EXTRA_PERSON, Person::class.java)
        return res
    }
}