package dev.mobile.tp2quiz.data

const val NO_OF_QUESTIONS = 5
data class Question(
    val text: String,
    val answer: Boolean
)

object QuizData {
    val allQuestions = listOf(
        Question("En binaire non signé, le nombre 1010 représente-il la valeur décimale 10 ?", true),
        Question("Le bit de poids fort est le bit le plus à gauche", false),
        Question("Le bit de poids faible indique-t-il le signe du nombre ?", false),
        Question("Pour obtenir l'opposé d'un nombre en C2, on inverse tous les bits", false),
        Question("En grand boutien, l'octet le plus significatif est stocké à l'adresse mémoire la plus basse", true),
        Question("Le standard IEEE 754 est-il utilisé pour représenter les nombres entiers ?", false),
        Question("Un octet contient 8 bits", true),
        Question("Le code UCS-2 utilise-t-il 16 bits pour coder un caractère ?", true),
        Question("Unicode comporte plusieurs représentations",true),
        Question("Est-il possible de représenter exactement 0,1 avec un nombre fini de bits ?",false)

    )
}