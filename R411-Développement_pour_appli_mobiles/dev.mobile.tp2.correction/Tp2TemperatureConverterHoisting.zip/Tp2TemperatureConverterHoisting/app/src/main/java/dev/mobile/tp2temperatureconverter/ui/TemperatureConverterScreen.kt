package dev.mobile.tp2temperatureconverter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import dev.mobile.tp2temperatureconverter.TemperatureCalculator
import dev.mobile.tp2temperatureconverter.ui.theme.Tp2TemperatureConverterTheme
import kotlin.text.toFloatOrNull

@Composable
fun TemperatureConverterScreen(modifier: Modifier = Modifier) {
    // Etat donné par celsius exclusivement
    var celsiusValue by remember { mutableStateOf(0f) }

    // farenheit dépend de celsius et est recalculé à chaque recomposition
    val fahrenheitValue = TemperatureCalculator.celsiusToFahrenheit(celsiusValue)

    // Appel du composant stateless
    TemperatureConverterComponent(
        celsiusValue,
        fahrenheitValue,
        {
            celsiusValue = it
        },
        onFahrenheitChange = {
            celsiusValue = TemperatureCalculator.fahrenheitToCelsius(it)
        },
        modifier
    )
}

// Composant stateless
@Composable
fun TemperatureConverterComponent(
    celsiusValue: Float,
    fahrenheitValue: Float,
    onCelsiusChange: (Float) -> Unit,
    onFahrenheitChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text(text = "Convertisseur de Température", style = MaterialTheme.typography.headlineMedium)

        Column {
            Text(text = "Celsius : ${celsiusValue.toInt()}°C")
            OutlinedTextField(
                value = celsiusValue.toInt().toString(),
                onValueChange = {
                    val c = it.toFloatOrNull() ?: 0f
                    onCelsiusChange(c)
                },
                label = { Text("Valeur Celsius") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        HorizontalDivider()

        Slider(
            value = celsiusValue,
            onValueChange = onCelsiusChange, // OU onValueChange = { onCelsiusChange(it)},
            valueRange = -100f..100f
        )

        HorizontalDivider()

        Column {
            Text(text = "Fahrenheit : ${fahrenheitValue.toInt()}°F")
            OutlinedTextField(
                value = fahrenheitValue.toInt().toString(),
                onValueChange = {
                    val f = it.toFloatOrNull() ?: 0f
                    onFahrenheitChange(f)
                },
                label = { Text("Valeur Fahrenheit") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Tp2TemperatureConverterTheme {
        TemperatureConverterScreen()
    }
}
