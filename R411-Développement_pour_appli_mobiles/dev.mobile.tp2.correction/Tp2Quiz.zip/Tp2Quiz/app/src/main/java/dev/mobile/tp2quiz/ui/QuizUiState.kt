package dev.mobile.tp2quiz.ui

data class QuizUiState(
    // texte de la question
    val question: String = "",

    // réponse affichée Correct/Faux
    val resultMessage: String = "",

    // question répondue oui/non
    val isAnswered: Boolean = false,

    // le score
    val score: Int = 0,

    // a-t-on fini le jeu
    val isGameOver: Boolean = false,

    // numéro de la question
    val questionNumber: Int = 1
)