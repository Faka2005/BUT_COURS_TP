package dev.mobile.tp3person

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import dev.mobile.tp3person.ui.PersonScreen
import dev.mobile.tp3person.ui.theme.Tp3PersonTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Tp3PersonTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                ) {
                    PersonScreen()
                }
            }
        }
    }
}