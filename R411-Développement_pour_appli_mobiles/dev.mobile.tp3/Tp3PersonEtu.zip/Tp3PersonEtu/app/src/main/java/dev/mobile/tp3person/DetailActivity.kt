package dev.mobile.tp3person

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import dev.mobile.tp3person.ui.DetailScreen
import dev.mobile.tp3person.ui.theme.Tp3PersonTheme

class DetailActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PERSON = "PERSON_DATA"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Tp3PersonTheme {
                DetailScreen(
                    personToEdit = null,
                    onSave = {  },
                    onCancel = {  }
                )
            }
        }
    }
}


