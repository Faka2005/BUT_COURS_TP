package dev.mobile.demointent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import dev.mobile.demointent.ui.theme.DemoIntentTheme
import android.app.Activity
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.unit.dp


class SecondActivity : ComponentActivity() {

    companion object {
        const val CLE = "cle"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val valeurRecue = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""

        setContent {
            MaterialTheme {
                SecondScreen(
                    valeurInitiale = valeurRecue,
                    onBackNormal = {  },
                    onBackWithResult = { saisi ->
                        val resultIntent = Intent().putExtra(CLE, saisi.toIntOrNull() ?: 0)
                        setResult(Activity.RESULT_OK, resultIntent)
                        finish()
                    }
                )
            }
        }
    }
}

@Composable
fun SecondScreen(valeurInitiale: String, onBackNormal: () -> Unit, onBackWithResult: (String) -> Unit) {
    var textSaisie by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(text = valeurInitiale, style = MaterialTheme.typography.headlineLarge)

        OutlinedTextField(
            value = textSaisie,
            onValueChange = { textSaisie = it },
            label = { Text("Nombre à retourner") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = onBackNormal) { Text("Retour normal") }

        Button(onClick = { onBackWithResult(textSaisie) }) {
            Text("Retour avec réponse")
        }
    }
}
