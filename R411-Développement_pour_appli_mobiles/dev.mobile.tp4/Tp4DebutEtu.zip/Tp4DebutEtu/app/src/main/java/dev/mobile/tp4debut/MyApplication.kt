package dev.mobile.tp4debut

import android.app.Application
import android.util.Log
import dev.mobile.tp4debut.data.MyRepository
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logger
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.plugins.observer.ResponseObserver
import kotlin.getValue

class MyApplication : Application() {
    private val httpClient by lazy {
        HttpClient(Android)
    }

    val repository by lazy {
        MyRepository(httpClient)
    }
}