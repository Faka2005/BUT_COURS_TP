package dev.mobile.demonetwork.data.repository

import dev.mobile.demonetwork.data.data.model.Post
import dev.mobile.demonetwork.data.remote.PostRemoteDataSource

class PostRepository(private val dataSource: PostRemoteDataSource) {

    // Je peux également choisir de définir une classe personalisée plutôt que d'utiliser Result

    suspend fun getPosts(): Result<List<Post>> =
        try {
            Result.success(dataSource.fetchPosts())
        } catch (e: Throwable) {
            Result.failure(e)
        }
}