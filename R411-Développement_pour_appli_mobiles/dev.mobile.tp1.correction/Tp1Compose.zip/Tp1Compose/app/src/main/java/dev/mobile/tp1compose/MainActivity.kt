package dev.mobile.tp1compose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.mobile.tp1compose.ui.theme.Tp1ComposeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Tp1ComposeTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Composable
fun SimpleStack() {
    Column() {
        Text(
            text = "Titre de l'App",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Blue
        )
        Text(
            text = "Sous-titre",
            fontSize = 18.sp,
            fontStyle = FontStyle.Italic,
            color = Color.Gray,
            modifier = Modifier.align(Alignment.End)
        )
        Text(
            text = stringResource(R.string.lorem),
            letterSpacing = 4.sp
        )

        Row (horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()){
            Icon(Icons.Default.Star, contentDescription = null)
            Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.Red)
        }
    }
}

@Composable
fun CenterGrid_Box() {
    Box  (
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Grid()
    }
}

@Composable
fun CenterGrid_Row() {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Grid()
    }
}

@Composable
fun CenterGrid_Column() {
    Column  (
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment =  Alignment.CenterHorizontally
    ) {
        Grid()
    }
}

@Composable
fun Grid(){
    Column(modifier = Modifier.padding(12.dp)) {
        Row {
            TextLikeButton("Texte 1")
            TextLikeButton("Texte 2")
        }
        TextLikeButton("Texte 3", modifier = Modifier.size(85.dp))
        TextLikeButton("Texte 4")
    }
}

@Composable
fun TextLikeButton(
    title: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(8.dp)
            .background(Color.LightGray, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ProfileCard() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            imageVector =  Icons.Default.AccountCircle, // à changer ?
            contentDescription = "Photo",
            modifier = Modifier.size(100.dp)
        )

        Text(text = "Jean Dupont", style = MaterialTheme.typography.headlineMedium)
        Text(text = "Étudiant IUT")

        Row(
            modifier = Modifier.padding(top = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Icon(Icons.Default.Call, contentDescription = "Appeler")
            Icon(Icons.Default.Email, contentDescription = "Email")
            Icon(Icons.Default.Share, contentDescription = "Partager")
        }
    }
}

@Composable
fun SimpleForm() {
    var name= ""
    var age = 25f

    val options = listOf("Débutant", "Intermédiaire", "Expert")
    var selectedOption = options[1]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(ScrollState(0)),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Mon Profil", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = name,
            onValueChange = { },
            label = { Text("Nom complet") },
            modifier = Modifier.fillMaxWidth()
        )

        Column {
            Text("Âge : ${age.toInt()} ans")
            Slider(
                value = age,
                onValueChange = {  },
                valueRange = 18f..99f
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = true,
                onCheckedChange = {  }
            )
            Text("S'abonner à la newsletter")
        }
        Column {
            Text("Niveau d'expérience :")
            Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    options.forEach { text ->
                        FilterChip(
                            selected = (text == selectedOption),
                            onClick = { },
                            label = { Text(text) },
                            leadingIcon = if (text == selectedOption) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
                            } else null
                        )
                    }
            }
        }

        Button(
            onClick = { },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Enregistrer")
        }
    }
}



@Preview(showBackground = true)
@Composable
fun SimpleStackPreview() {
    Tp1ComposeTheme {
        SimpleStack()
    }
}
@Preview(showBackground = true)
@Composable
fun GridPreview() {
    Tp1ComposeTheme {
        Grid()
    }
}
@Preview(showBackground = true)
@Composable
fun ProfileCardPreview() {
    Tp1ComposeTheme {
        ProfileCard()
    }
}
@Preview(showBackground = true)
@Composable
fun SimpleFormPreview() {
    Tp1ComposeTheme {
        SimpleForm()
    }
}