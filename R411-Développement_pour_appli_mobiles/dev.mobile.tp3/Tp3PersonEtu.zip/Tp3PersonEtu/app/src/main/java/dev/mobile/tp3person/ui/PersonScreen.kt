package dev.mobile.tp3person.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mobile.tp3person.AddPersonContract
import dev.mobile.tp3person.DetailActivity
import dev.mobile.tp3person.Person
import dev.mobile.tp3person.PersonData

@Composable
fun PersonScreen() {
    val people = PersonData.allPersons.toMutableStateList()

    Column(
        modifier = Modifier.Companion.fillMaxSize()
    ) {
        Button(
            onClick = { },
            modifier = Modifier.Companion.padding(start = 24.dp, end = 24.dp).fillMaxWidth()) {
            Text("Ajouter une personne")
        }
        PersonList(
            persons = people,
            onPersonClick = {}
        )
    }
}

@Composable
fun PersonList(persons : List<Person>, onPersonClick: (Person) -> Unit) {
    TODO()
    LazyColumn{
        // Appel de PersonItem pour chaque Person de la List
    }
}

@Composable
fun PersonItem(person: Person, onClick : () -> Unit ) {
    Text(
        text = "${person.firstName} ${person.lastName}",
        style = MaterialTheme.typography.headlineMedium,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(8.dp))
}