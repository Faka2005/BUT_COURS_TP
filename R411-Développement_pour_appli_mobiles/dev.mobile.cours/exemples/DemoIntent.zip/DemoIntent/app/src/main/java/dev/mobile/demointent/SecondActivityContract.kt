package dev.mobile.demointent

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContract

class SecondActivityContract : ActivityResultContract<String, Int>() {
    override fun createIntent(context: Context, input: String): Intent {
        return Intent(context, SecondActivity::class.java).putExtra(Intent.EXTRA_TEXT, input)
    }

    override fun parseResult(resultCode: Int, intent: Intent?): Int {
        return if (resultCode == Activity.RESULT_OK) {
            intent?.getIntExtra(SecondActivity.CLE, -1) ?: -1
        } else -1
    }
}