package dev.mobile.tp2quiz.ui

import androidx.lifecycle.ViewModel
import dev.mobile.tp2quiz.data.NO_OF_QUESTIONS
import dev.mobile.tp2quiz.data.Question
import dev.mobile.tp2quiz.data.QuizData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class QuizViewModel : ViewModel() {


    // Questions pour ce Quiz
    private lateinit var questions: List<Question>
    private var index = 0


    private val _uiState = MutableStateFlow(QuizUiState())
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()

    init {
        resetQuiz()
    }

    fun resetQuiz() {
        // Mélanger et piocher NO_OF_QUESTIONS questions
        questions = QuizData.allQuestions.shuffled().take(NO_OF_QUESTIONS)
        index = 0

        // Mettre à jour l'état avec la première question
        _uiState.value = QuizUiState(
            question = questions[index].text,
            questionNumber = 1
        )
    }

    fun checkAnswer(userAnswer: Boolean) {
        // Bonne réponse ?
        val isCorrect = questions[index].answer == userAnswer

        // // Mettre à jour l'état . Utilisation de update de MujtableStateFlow et copy de data class
        _uiState.update { currentState ->
            currentState.copy(
                resultMessage = if (isCorrect) "Correct ! ✅" else "Faux... ❌",
                score = if (isCorrect) currentState.score + 1 else currentState.score,
                isAnswered = true
            )
        }
    }

    fun nextQuestion() {
        // Encore des questions
        if (index < NO_OF_QUESTIONS - 1) {
            index++
            _uiState.update { it.copy(
                question = questions[index].text,
                questionNumber = index + 1,
                resultMessage = "",
                isAnswered = false
            )}
        } else {
            // FIN
            _uiState.update { it.copy(isGameOver = true) }
        }
    }
}