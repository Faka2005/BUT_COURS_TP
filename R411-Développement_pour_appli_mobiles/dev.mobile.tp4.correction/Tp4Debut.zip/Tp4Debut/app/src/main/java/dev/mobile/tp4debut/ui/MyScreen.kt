package dev.mobile.tp4debut.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage


@Composable
fun MyScreen(modifier: Modifier = Modifier, viewModel: MyViewModel  = viewModel(factory = MyViewModel.Factory)) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        Row {
            Button(onClick = { viewModel.fetchJson(4) }) { Text("json") }
            Button(onClick = { viewModel.fetchGet() }) { Text("get") }
            Button(onClick = { viewModel.fetchImage() }) { Text("image") }
            Button(onClick = { viewModel.fetchPost() }) { Text("post") }
        }
        Spacer(modifier = Modifier.height(16.dp))

        when (val state = uiState) {
            is ScreenState.Idle -> Text("Appuyez sur un bouton")
            is ScreenState.Loading -> CircularProgressIndicator()
            is ScreenState.SuccessText -> Text("${state.theText}")
            is ScreenState.SuccessPost -> Text("Titre : ${state.thePost.title}")
            is ScreenState.Error -> Text("Erreur : ${state.message}", color = Color.Red)
            is ScreenState.SuccessImage -> {
                AsyncImage(
                    model = state.theUrl,
                    contentDescription = "Image",
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
