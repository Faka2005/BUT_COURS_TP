package dev.mobile.tp2temperatureconverter.util

class TemperatureCalculator {
    companion object {
        fun celsiusToFahrenheit(celsius: Float): Float = (celsius * 9 / 5) + 32

        fun fahrenheitToCelsius(fahrenheit: Float): Float = (fahrenheit - 32) * 5 / 9
    }
}