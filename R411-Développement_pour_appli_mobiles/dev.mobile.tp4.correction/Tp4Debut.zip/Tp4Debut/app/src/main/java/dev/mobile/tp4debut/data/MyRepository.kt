package dev.mobile.tp4debut.data

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.forms.submitForm
import io.ktor.client.request.get
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.parameters

class MyRepository (private val client: HttpClient) {

    suspend fun get(): Resource<String> {
        return try {
            val response: String = client.get("https://www.perdu.com").bodyAsText()
            Resource.Success(response)
        } catch (e: Exception) {
            Resource.Error(e)
        }
    }
    suspend fun post(): Resource<String> {
        return try {
            val response: HttpResponse = client.submitForm(
                url = "https://httpbin.org/post",
                formParameters = parameters {
                    append("username", "lanoix")
                    append("password", "lechef")
                }
            )
            Resource.Success(response.bodyAsText())
        } catch (e: Exception) {
            Resource.Error(e)
        }
    }

    suspend fun image(): Resource<String> {
        // Ici, pas de try/catch nécessaire car c'est une simple String en dur,
        // mais on garde la signature Resource pour la cohérence.
        return Resource.Success("https://picsum.photos/200/300")
    }

    suspend fun json(id: Int): Resource<Todo> {
        return try {
            // Tentative d'appel réseau et de désérialisation JSON
            val response: Todo = client.get("https://jsonplaceholder.typicode.com/posts/$id").body()
            // Si ça réussit, on renvoie le succès
            Resource.Success(response)
        } catch (e: Exception) {
            // Si une exception survient (Timeout, 404, JSON mal formé...), on renvoie l'erreur
            Resource.Error(e)
        }
    }

}