package dev.mobile.tp3person.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mobile.tp3person.AddPersonContract
import dev.mobile.tp3person.DetailActivity
import dev.mobile.tp3person.Person
import dev.mobile.tp3person.PersonData

@Composable
fun PersonScreen() {
    val people = rememberSaveable { PersonData.allPersons.toMutableStateList() }
    val context = LocalContext.current

    val secondLauncher = rememberLauncherForActivityResult (AddPersonContract()) {
        // contrat personnalisé : OUTPUT = une Person?
            result ->
        if (result!=null) {
            val index = people.indexOfFirst { it.id == result.id }
            if (index != -1) {
                people[index] = result // Mise à jour
            } else {
                people.add(result) // Ajout ; nouvelle entrée
            }
        }
    }

    Column(
        modifier = Modifier.Companion.fillMaxSize()
    ) {
        Button(
            onClick = { secondLauncher.launch(null)},
            modifier = Modifier.Companion.padding(start = 24.dp, end = 24.dp).fillMaxWidth()) {
            Text("Ajouter une personne")
        }
        PersonList(
            persons = people,
            onPersonClick = { person ->
                println("Clic sur : ${person.firstName}")
               // val index = people.indexOf(person)
               // people[index] = person.toUpercase()

                val intent = Intent(context, DetailActivity::class.java).apply {
                    putExtra("PERSON_DATA", person)
                }
                context.startActivity(intent)
            })

    }
}

@Composable
fun PersonList(persons : List<Person>, onPersonClick: (Person) -> Unit) {
    val state = rememberLazyListState()

    LazyColumn(
        state = state,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.Companion.padding(start = 24.dp, end = 24.dp).fillMaxSize()
    ) {
        items(persons) { person ->
            PersonItem(
                person = person,
                onClick = { onPersonClick(person) }
            )
        }
    }
}

@Composable
fun PersonItem(person: Person, onClick : () -> Unit ) {
    Text(
        text = "${person.firstName} ${person.lastName}",
        style = MaterialTheme.typography.headlineMedium,
        modifier = Modifier.Companion
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(8.dp))
}