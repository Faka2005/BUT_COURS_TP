package dev.mobile.tp4debut.data

data class Todo(
    val userId: Int,
    val id: Int,
    val title: String,
    val completed: Boolean
)

