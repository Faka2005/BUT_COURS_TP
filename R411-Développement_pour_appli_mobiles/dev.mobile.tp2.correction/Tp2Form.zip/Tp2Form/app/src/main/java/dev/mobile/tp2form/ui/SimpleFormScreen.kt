package dev.mobile.tp2form.ui

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import dev.mobile.tp2form.ui.theme.Tp2FormTheme

@Composable
fun SimpleFormScreen() {

    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf(25f) }
    val options = listOf("Débutant", "Intermédiaire", "Expert")
    var selectedOption by remember { mutableStateOf(options[0]) }
    var isSubscribed by remember { mutableStateOf(true) }


    Column(
        modifier = Modifier.Companion
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(ScrollState(0)),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Mon Profil", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = name,
            onValueChange = {it -> name = it },
            label = { Text("Nom complet") },
            modifier = Modifier.Companion.fillMaxWidth()
        )

        Column {
            Text("Âge : ${age.toInt()} ans")
            Slider(
                value = age,
                onValueChange = { age = it },
                valueRange = 18f..99f
            )
        }

        Row(verticalAlignment = Alignment.Companion.CenterVertically) {
            Checkbox(
                checked = isSubscribed,
                onCheckedChange = { isSubscribed = it}
            )
            Text("S'abonner à la newsletter")
        }
        Column {
            Text("Niveau d'expérience :")
            Row(
                modifier = Modifier.Companion.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                options.forEach { text ->
                    FilterChip(
                        selected = (text == selectedOption),
                        onClick = { selectedOption = text },
                        label = { Text(text) },
                        leadingIcon = if (text == selectedOption) {
                            {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.Companion.size(18.dp)
                                )
                            }
                        } else null
                    )
                }
            }
        }

        Button(
            onClick = { },
            modifier = Modifier.Companion.align(Alignment.Companion.End)
        ) {
            Text("Enregistrer")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SimpleFormPreview() {
    Tp2FormTheme {
        SimpleFormScreen()
    }
}