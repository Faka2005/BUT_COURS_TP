package dev.mobile.demonetwork.ui.posts

import dev.mobile.demonetwork.data.data.model.Post

sealed interface PostUiState {
    data object Loading : PostUiState
    data class Success(val posts: List<Post>) : PostUiState
    data class Error(val message: String) : PostUiState
}