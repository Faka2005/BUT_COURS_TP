package dev.mobile.tp3person.ui

import android.database.Cursor
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mobile.tp3person.Person

@Composable
fun DetailScreen(
    personToEdit: Person?,
    onSave: (Person) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val isReadOnly = personToEdit != null
    var person by remember {
        mutableStateOf(personToEdit ?: Person(firstName = "", lastName = "", phone = ""))
    }

    // Launcher pour le sélecteur de contacts
    val contactPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickContact()
    ) { uri ->
        /*
        if (uri!=null) {
            val projection = arrayOf(ContactsContract.Contacts.DISPLAY_NAME)
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val name = cursor.getString(0)
                    person= person.copy(lastName = name)
                }
            }
        }*/
        if (uri!=null) {
            val cursor: Cursor? = context.contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val name: String =
                    cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME))
                // name est le nom du contact sélectionné
                person= person.copy(lastName = name)
                cursor.close()
            }
        }
    }


    Scaffold { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Champ Prénom
            OutlinedTextField(
                value = person.firstName,
                onValueChange = { person = person.copy(firstName = it) },
                label = { Text("Prénom") },
                enabled = !isReadOnly, // Inactif si lecture seule
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    IconButton(onClick = { contactPickerLauncher.launch(null) }) {
                        Icon(Icons.Default.Person, contentDescription = "Pick Contact")
                    }
                }
            )

            // Champ Nom
            OutlinedTextField(
                value = person.lastName,
                onValueChange = { person = person.copy(lastName = it) },
                label = { Text("Nom") },
                enabled = !isReadOnly,
                modifier = Modifier.fillMaxWidth()
            )

            // Champ Téléphone
            OutlinedTextField(
                value = person.phone,
                onValueChange = { person = person.copy(phone = it) },
                label = { Text("Téléphone") },
                enabled = !isReadOnly,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { onCancel() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Retour")
            }

            if (!isReadOnly) {
                Button(
                    onClick = { onSave(person) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = person.firstName.isNotBlank() && person.lastName.isNotBlank()
                ) {
                    Text("Enregistrer")
                }
            }
        }
    }
}