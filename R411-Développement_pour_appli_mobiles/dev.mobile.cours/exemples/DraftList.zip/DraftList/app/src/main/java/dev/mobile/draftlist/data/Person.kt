package dev.mobile.draftlist.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

data class Person (
    val firstName: String,
    val lastName: String,
    val birthDate: LocalDate,
    val id: String = UUID.randomUUID().toString()
) {
    private val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    fun toUppercase() : Person = this.copy(lastName=lastName.uppercase(Locale.getDefault()))

    val formattedBirthDate: String
        get() = birthDate.format(formatter)

    override fun toString(): String = "$firstName $lastName $formattedBirthDate"

    companion object {
        fun create(firstName: String, lastName: String, year: Int, month: Int, day: Int): Person? {
            return try {
                val date = LocalDate.of(year, month, day)
                Person(firstName, lastName, birthDate = date) // Succès : on retourne la Personne
            } catch (e: Exception) {
                null // Échec : on retourne null proprement
            }
        }
    }
}
