package dev.mobile.demonetwork.ui.posts
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.launch
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import dev.mobile.demonetwork.DemoNetworkApplication
import dev.mobile.demonetwork.data.repository.PostRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PostViewModel(private val repository: PostRepository) : ViewModel() {


    private val _uiState = MutableStateFlow<PostUiState>(PostUiState.Loading)
    val uiState: StateFlow<PostUiState> = _uiState.asStateFlow()

    init { loadPosts() }

    fun loadPosts() {

        // c'est ici que je fait la correspondance entre ce qui est remonté par l'utilisation de l'API (un Result à success ou failure) et l'état pour l'UI

        _uiState.value = PostUiState.Loading
        viewModelScope.launch {
            val  res = repository.getPosts()
                .onSuccess { _uiState.value = PostUiState.Success(it) }
                .onFailure { _uiState.value = PostUiState.Error(it.message ?: "Erreur réseau") }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = (this[APPLICATION_KEY] as DemoNetworkApplication)
                PostViewModel(repository = app.repository)
            }
        }
    }
}