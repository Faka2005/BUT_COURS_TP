package dev.mobile.draftlist.data

import java.time.LocalDate

object PersonData {
    val allPersons: List<Person> = listOf(
        Person("Thalès", "de Milet", LocalDate.of(-624, 1, 1)),
        Person("Pythagore", "de Samos", LocalDate.of(-570, 1, 1)),
        Person("Euclide", "d'Alexandrie", LocalDate.of(-300, 1, 1)),
        Person("Blaise", "Pascal", LocalDate.of(1623, 6, 19)),
        Person("Pierre", "de Fermat", LocalDate.of(1601, 8, 17)),
        Person("Leonhard", "Euler", LocalDate.of(1707, 4, 15)),

        Person("Carl Friedrich", "Gauss", LocalDate.of(1777, 4, 30)),
        Person("Augustin-Louis", "Cauchy", LocalDate.of(1789, 8, 21)),
        Person("Peter Gustav Lejeune", "Dirichlet", LocalDate.of(1805, 2, 13)),
        Person("Bernhard", "Riemann", LocalDate.of(1826, 9, 17)),
        Person("Georg", "Cantor", LocalDate.of(1845, 3, 3)),
        Person("Henri", "Poincaré", LocalDate.of(1854, 4, 29)),

        Person("Emmy", "Noether", LocalDate.of(1882, 3, 23)),
        Person("Andrey", "Kolmogorov", LocalDate.of(1903, 4, 25)),
        Person("Joseph", "Fourier", LocalDate.of(1768, 3, 21)),
        Person("Évariste", "Galois", LocalDate.of(1811, 10, 25)),
        Person("Srinivasa", "Ramanujan", LocalDate.of(1887, 12, 22)),
        Person("Kurt", "Gödel", LocalDate.of(1906, 4, 28)),
        Person("John", "von Neumann", LocalDate.of(1903, 12, 28)),
        Person("Benoît", "Mandelbrot", LocalDate.of(1924, 11, 20)),
        Person("Sophie", "Germain", LocalDate.of(1776, 4, 1)),
        Person("Katherine", "Johnson", LocalDate.of(1918, 8, 26)),
        Person("Maryam", "Mirzakhani", LocalDate.of(1977, 5, 12))
    )
}