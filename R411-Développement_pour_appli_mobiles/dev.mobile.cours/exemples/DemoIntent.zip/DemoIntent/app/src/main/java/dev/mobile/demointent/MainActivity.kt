package dev.mobile.demointent

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import dev.mobile.demointent.ui.theme.DemoIntentTheme
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContent {
            DemoIntentTheme {
                Column {
                    MainScreen()
                }
            }
        }
    }
}


@Composable
fun MainScreen() {
    val context = LocalContext.current
    var textVisualisation by remember { mutableStateOf("") }
    var textSaisie by remember { mutableStateOf("") }

    // Launcher pour contrat personnalisé
    val secondIntLauncher = rememberLauncherForActivityResult(SecondActivityContract()) { result ->
        Toast.makeText(context, "reçu : $result", Toast.LENGTH_LONG).show()
        textVisualisation = result.toString()
    }

    // Launcher générique (Raw)
    val secondRawLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data?.getIntExtra(SecondActivity.CLE, -1)
            textVisualisation = data.toString()
        }
    }

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        imageUri = uri
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(text = "Résultat : $textVisualisation", style = MaterialTheme.typography.headlineSmall)

        OutlinedTextField(
            value = textSaisie,
            onValueChange = { textSaisie = it },
            label = { Text("Saisie") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = {
            context.startActivity(Intent(context, SecondActivity::class.java))
        }) { Text("Autre activité explicite") }

        Button(onClick = {
            val c = Calendar.getInstance()
            val versAutre = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Demo")
                .putExtra(AlarmClock.EXTRA_HOUR, c[Calendar.HOUR_OF_DAY])
                .putExtra(AlarmClock.EXTRA_MINUTES, c[Calendar.MINUTE] + 1)
            context.startActivity(versAutre)
        }) { Text("Autre activité implicite") }


        Button(onClick = {
            val intent = Intent(context, SecondActivity::class.java)
                .putExtra(Intent.EXTRA_TEXT, textSaisie)

            context.startActivity(intent)
        }) { Text("Avec donnée") }

        Button(onClick = {
            secondIntLauncher.launch("Contrat")
        }) { Text("Avec retour (Contrat)") }

        Button(onClick = {
            val intent = Intent(context, SecondActivity::class.java)
                .putExtra(Intent.EXTRA_TEXT, "Raw")
            secondRawLauncher.launch(intent)
        }) { Text("Avec retour (Raw)") }

        Button(onClick = { imageLauncher.launch("image/*") }) {
            Text(text = "Load Image")
        }

        Image(
            painter = rememberAsyncImagePainter(imageUri),
            contentDescription = "My Image"
        )

    }
}
